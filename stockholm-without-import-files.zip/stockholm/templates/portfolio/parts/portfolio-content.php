<h3 class="info_section_title"><?php the_title(); ?></h3>
<div class="info portfolio_single_content">
	<?php the_content(); ?>
</div> <!-- close div.portfolio_content -->